CREATE DATABASE  IF NOT EXISTS `pizzaria-uds` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `pizzaria-uds`;
-- MySQL dump 10.13  Distrib 5.7.23, for Linux (x86_64)
--
-- Host: localhost    Database: pizzaria-uds
-- ------------------------------------------------------
-- Server version	5.7.23-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedido`
--

DROP TABLE IF EXISTS `pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedido` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fk_tamanho_pizza` int(10) unsigned NOT NULL,
  `fk_sabor_pizza` int(10) unsigned NOT NULL,
  `situacao` enum('Montagem','Personalização','Finalizado') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pedido_fk_tamanho_pizza_foreign` (`fk_tamanho_pizza`),
  KEY `pedido_fk_sabor_pizza_foreign` (`fk_sabor_pizza`),
  CONSTRAINT `pedido_fk_sabor_pizza_foreign` FOREIGN KEY (`fk_sabor_pizza`) REFERENCES `pizza_sabor` (`id`),
  CONSTRAINT `pedido_fk_tamanho_pizza_foreign` FOREIGN KEY (`fk_tamanho_pizza`) REFERENCES `pizza_tamanho` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido`
--

LOCK TABLES `pedido` WRITE;
/*!40000 ALTER TABLE `pedido` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedido_personalizacao`
--

DROP TABLE IF EXISTS `pedido_personalizacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pedido_personalizacao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `fk_pedido` int(10) unsigned NOT NULL,
  `fk_personalizacao` int(10) unsigned NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pedido_personalizacao_fk_pedido_foreign` (`fk_pedido`),
  KEY `pedido_personalizacao_fk_personalizacao_foreign` (`fk_personalizacao`),
  CONSTRAINT `pedido_personalizacao_fk_pedido_foreign` FOREIGN KEY (`fk_pedido`) REFERENCES `pedido` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pedido_personalizacao_fk_personalizacao_foreign` FOREIGN KEY (`fk_personalizacao`) REFERENCES `pizza_personalizacao` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedido_personalizacao`
--

LOCK TABLES `pedido_personalizacao` WRITE;
/*!40000 ALTER TABLE `pedido_personalizacao` DISABLE KEYS */;
/*!40000 ALTER TABLE `pedido_personalizacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pizza_personalizacao`
--

DROP TABLE IF EXISTS `pizza_personalizacao`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pizza_personalizacao` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` double(10,2) NOT NULL DEFAULT '0.00',
  `tempo_adicional` time NOT NULL DEFAULT '00:00:00',
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pizza_personalizacao`
--

LOCK TABLES `pizza_personalizacao` WRITE;
/*!40000 ALTER TABLE `pizza_personalizacao` DISABLE KEYS */;
INSERT INTO `pizza_personalizacao` VALUES (1,'Extra Bacon',3.00,'00:00:00',1,NULL,NULL),(2,'Sem Cebola',0.00,'00:00:00',1,NULL,NULL),(3,'Borda Recheada',5.00,'00:05:00',1,NULL,NULL);
/*!40000 ALTER TABLE `pizza_personalizacao` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pizza_sabor`
--

DROP TABLE IF EXISTS `pizza_sabor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pizza_sabor` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tempo_adicional` time NOT NULL DEFAULT '00:00:00',
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pizza_sabor`
--

LOCK TABLES `pizza_sabor` WRITE;
/*!40000 ALTER TABLE `pizza_sabor` DISABLE KEYS */;
INSERT INTO `pizza_sabor` VALUES (1,'Calabresa','00:00:00',1,NULL,NULL),(2,'Marguerita','00:00:00',1,NULL,NULL),(3,'Portuguesa','00:05:00',1,NULL,NULL);
/*!40000 ALTER TABLE `pizza_sabor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pizza_tamanho`
--

DROP TABLE IF EXISTS `pizza_tamanho`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pizza_tamanho` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descricao` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` double(10,2) NOT NULL DEFAULT '0.00',
  `tempo_adicional` time NOT NULL DEFAULT '00:00:00',
  `status` int(11) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pizza_tamanho`
--

LOCK TABLES `pizza_tamanho` WRITE;
/*!40000 ALTER TABLE `pizza_tamanho` DISABLE KEYS */;
INSERT INTO `pizza_tamanho` VALUES (1,'Pequena',20.00,'00:15:00',1,NULL,NULL),(2,'Média',30.00,'00:20:00',1,NULL,NULL),(3,'Grande',40.00,'00:25:00',1,NULL,NULL);
/*!40000 ALTER TABLE `pizza_tamanho` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-10-07 16:37:00
